| __ )(_) |_    |  _ \ ___ _ __   ___  ___(_) |_ ___  _ __ _   _ 
|  _ \| | __|   | |_) / _ \ '_ \ / _ \/ __| | __/ _ \| '__| | | |
| |_) | | |_    |  _ <  __/ |_) | (_) \__ \ | || (_) | |  | |_| |
|____/|_|\__|   |_| \_\___| .__/ \___/|___/_|\__\___/|_|   \__, |
                        |_|                              |___/ 


This archive is downloaded from http://www.bitrepository.com/. Visit us for more snippets & tutorials.